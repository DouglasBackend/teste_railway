// @ts-nocheck
import React from 'react';
import { useCurrentFrame, useVideoConfig, interpolate, spring } from 'remotion';

export const SubtitleOverlay: React.FC<{
  words: {text: string, start: number, end: number}[];
  style: any;
}> = ({ words, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentTime = frame / fps;

  const validWords = words.filter(w => w.text.trim().length > 0);
  const activeWordIdx = validWords.findIndex(w => currentTime >= w.start && currentTime <= w.end);

  if (activeWordIdx === -1) return null;

  const preset = (style?.preset || 'tiktok').toLowerCase();
  const maxWords = style?.max_words !== undefined ? Number(style.max_words) : 1;

  const fontFamily = style?.fontFamily || style?.font_family || 'Bangers, Impact, sans-serif';
  const fontColor = style?.font_color || '#FFFFFF';
  const highlightColor = style?.highlight_color || '#FFC402';
  const outlineColor = style?.outline_color || '#000000';
  const outlineWidth = style?.outline_width !== undefined ? Number(style.outline_width) : 3;
  const bgColor = style?.background_color || 'transparent';
  const shadowDepth = style?.shadow_depth !== undefined ? Number(style.shadow_depth) : 0;
  const fontSizePx = style?.font_size !== undefined ? Number(style.font_size) : 90;
  const posY = style?.posY !== undefined ? Number(style.posY) : 78;

  const groupSize = maxWords;
  const currentGroupIdx = Math.floor(activeWordIdx / groupSize);
  const wordsToShow = validWords.filter((_, i) => Math.floor(i / groupSize) === currentGroupIdx);

  return (
    <div style={{
      position: 'absolute',
      top: `${posY}%`,
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: '90%',
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      alignItems: 'center',
      gap: '15px 25px',
      zIndex: 9999
    }}>
      {wordsToShow.map((w, i) => {
        const isActive = currentTime >= w.start && currentTime <= w.end;
        const elapsed = isActive ? frame - (w.start * fps) : 0;
        return (
          <WordRenderer
            key={`${w.text}-${i}`}
            text={w.text}
            isActive={isActive}
            elapsed={elapsed}
            frame={frame}
            fps={fps}
            preset={preset}
            fontFamily={fontFamily}
            fontColor={fontColor}
            highlightColor={highlightColor}
            outlineColor={outlineColor}
            outlineWidth={outlineWidth}
            bgColor={bgColor}
            shadowDepth={shadowDepth}
            fontSizePx={fontSizePx}
          />
        );
      })}
    </div>
  );
};

const WordRenderer: React.FC<{
  text: string; isActive: boolean; elapsed: number; frame: number; fps: number;
  preset: string; fontFamily: string; fontColor: string; highlightColor: string;
  outlineColor: string; outlineWidth: number; bgColor: string; shadowDepth: number; fontSizePx: number;
}> = ({ text, isActive, elapsed, frame, fps, preset, fontFamily, fontColor, highlightColor, outlineColor, outlineWidth, bgColor, shadowDepth, fontSizePx }) => {

  const animType = preset.toLowerCase();

  let style: React.CSSProperties = {
    fontFamily,
    fontSize: `${fontSizePx}px`,
    fontWeight: 'bold',
    textAlign: 'center' as const,
    textTransform: 'uppercase' as const,
    display: 'inline-block',
    lineHeight: 1.1,
    position: 'relative',
  };

  if (bgColor && bgColor !== 'transparent') {
    style.backgroundColor = bgColor;
    style.padding = '10px 24px';
    style.borderRadius = '12px';
  }

  if (outlineWidth > 0 && outlineColor !== 'transparent') {
    style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
  }

  if (shadowDepth > 0) {
    const shadows = Array.from({length: shadowDepth}, (_, d) =>
      `${d+1}px ${d+1}px 0px rgba(0,0,0,0.5)`
    ).join(', ');
    style.textShadow = shadows;
  }

  switch (animType) {

    case 'highlight': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 8, stiffness: 300 } });
      const scale = isActive ? interpolate(sp, [0, 1], [0.8, 1.1]) : 1;
      const pulseAlpha = isActive ? 0.2 + Math.sin(frame * 0.6) * 0.12 : 0;
      style.color = isActive ? highlightColor : fontColor;
      style.transform = `scale(${scale})`;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      if (isActive) {
        style.textShadow = `0 0 ${12 + Math.sin(frame * 0.5) * 4}px rgba(255,255,0,0.9)`;
        style.backgroundColor = `rgba(255,255,0,${pulseAlpha})`;
        style.padding = '8px 20px';
        style.borderRadius = '8px';
      }
      break;
    }

    case 'karaoke': {
      style.color = isActive ? 'transparent' : fontColor;
      if (isActive) {
        style.backgroundImage = 'linear-gradient(to right, #00ff88, #88ff00)';
        style.WebkitBackgroundClip = 'text';
        style.WebkitTextFillColor = 'transparent';
        style.WebkitTextStroke = '0px transparent';
        style.filter = 'drop-shadow(0 0 8px rgba(0,255,136,0.8))';
      } else {
        style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      }
      const sp = spring({ frame: elapsed, fps, config: { damping: 10, stiffness: 400 } });
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.7, 1.0]) : 1})`;
      break;
    }

    case 'tiktok': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 6, stiffness: 500 } });
      const sc = isActive ? interpolate(sp, [0, 1], [0.6, 1.12]) : 1;
      const yB = isActive ? interpolate(sp, [0, 0.5, 1], [0, -20, 0]) : 0;
      style.color = isActive ? highlightColor : fontColor;
      style.transform = `scale(${sc}) translateY(${yB}px)`;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      if (isActive) style.textShadow = `0 4px 12px rgba(0,0,0,0.5)`;
      break;
    }

    case 'impact': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 5, stiffness: 600 } });
      const sc = isActive ? interpolate(sp, [0, 1], [1.5, 1.2]) : 1;
      const rot = isActive ? Math.sin(frame * 0.3) * 3 : 0;
      style.color = isActive ? highlightColor : fontColor;
      style.transform = `scale(${sc}) rotate(${rot}deg)`;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.textShadow = isActive ? `0 0 ${10 + Math.sin(frame * 0.4) * 4}px ${fontColor}` : 'none';
      break;
    }

    case 'gradient':
    case 'gradientorig': {
      const hue = (frame * 2) % 360;
      style.backgroundImage = `linear-gradient(135deg, hsl(${hue},100%,60%), hsl(${(hue+120)%360},100%,60%), hsl(${(hue+240)%360},100%,60%))`;
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = '0px transparent';
      const sp = spring({ frame: elapsed, fps, config: { damping: 10, stiffness: 350 } });
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.8, 1.0]) : 0.9})`;
      break;
    }

    case 'cinematic': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 20, stiffness: 200 } });
      style.color = fontColor;
      style.opacity = isActive ? interpolate(sp, [0, 1], [0, 1]) : 0.7;
      style.backgroundColor = bgColor !== 'transparent' ? bgColor : `rgba(0,0,0,${0.7 + Math.sin(frame * 0.2) * 0.05})`;
      style.padding = '12px 28px';
      style.borderRadius = '0px';
      style.letterSpacing = '0.12em';
      style.WebkitTextStroke = '0px transparent';
      if (isActive) style.textShadow = `0 0 ${8 + Math.sin(frame * 0.4) * 3}px ${highlightColor}`;
      break;
    }

    case 'neon': {
      const oX = isActive ? Math.sin(frame * 0.5) * 3 : 0;
      const oY = isActive ? Math.cos(frame * 0.4) * 2 : 0;
      style.color = fontColor;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.transform = `translate(${oX}px, ${oY}px) skewX(${isActive ? oX * 2 : 0}deg)`;
      style.textShadow = isActive
        ? `-2px 0 0 #ff00ff, 2px 0 0 #00ffff, 0 0 ${18 + Math.sin(frame * 0.6) * 6}px ${highlightColor}`
        : `0 0 8px ${highlightColor}`;
      break;
    }

    case 'matrix': {
      const flashAlpha = isActive ? 0.5 + Math.sin(frame * 0.5) * 0.5 : 0.4;
      style.color = isActive ? `rgba(0,255,0,${flashAlpha})` : 'rgba(0,255,0,0.5)';
      style.fontFamily = "'Press Start 2P', monospace";
      style.WebkitTextStroke = '0px transparent';
      style.textShadow = isActive
        ? `0 0 ${10 + Math.sin(frame * 0.4) * 4}px #00FF00, 0 0 20px #00AA00`
        : '0 0 6px #00FF00';
      style.backgroundColor = `rgba(0,255,0,${isActive ? 0.15 : 0.05})`;
      style.padding = '8px 20px';
      style.borderRadius = '4px';
      style.transform = `scale(${isActive ? 1 + Math.sin(frame * 0.4) * 0.02 : 1})`;
      break;
    }

    case 'pop3d': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 7, stiffness: 500 } });
      const sc = isActive ? interpolate(sp, [0, 1], [0.5, 1.15]) : 1;
      const d3 = isActive
        ? Array.from({length: 5}, (_, i) => `${i+1}px ${i+1}px 0px ${outlineColor}`).join(', ')
        : `2px 2px 0px ${outlineColor}`;
      style.color = isActive ? highlightColor : fontColor;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.textShadow = d3;
      style.transform = `scale(${sc})`;
      break;
    }

    case 'liquid': {
      const wave = isActive ? Math.sin(frame * 0.3) * 4 : 0;
      const wave2 = isActive ? Math.cos(frame * 0.25) * 3 : 0;
      const hue = (frame * 1.5) % 360;
      style.backgroundImage = isActive
        ? `linear-gradient(${90 + wave * 5}deg, #ccc, #fff, hsl(${hue},60%,80%), #999)`
        : 'linear-gradient(90deg, #ccc, #fff, #999)';
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = `${outlineWidth}px rgba(180,180,255,0.5)`;
      style.transform = `translate(${wave2}px, ${wave * 0.5}px)`;
      style.filter = isActive ? `blur(0px) drop-shadow(0 0 6px rgba(180,180,255,0.6))` : 'none';
      break;
    }

    case 'explosive': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 4, stiffness: 700 } });
      const sc = isActive ? interpolate(sp, [0, 0.5, 1], [0.5, 1.4, 1.15]) : 1;
      const rot = isActive ? Math.sin(frame * 0.4) * 4 : 0;
      const hue = (frame * 3) % 360;
      style.color = isActive ? `hsl(${hue},100%,60%)` : fontColor;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.transform = `scale(${sc}) rotate(${rot}deg)`;
      style.textShadow = isActive
        ? `0 0 ${20 + Math.sin(frame * 0.5) * 8}px hsl(${hue},100%,70%)`
        : 'none';
      break;
    }

    case 'neonglow': {
      const hue = (frame * 2) % 360;
      const glowSize = isActive ? 20 + Math.sin(frame * 0.5) * 8 : 10;
      style.color = isActive ? `hsl(${hue},100%,70%)` : fontColor;
      style.WebkitTextStroke = '0px transparent';
      style.textShadow = isActive
        ? `0 0 ${glowSize}px hsl(${hue},100%,70%), 0 0 ${glowSize * 1.8}px hsl(${hue},100%,50%), 0 0 ${glowSize * 2.5}px hsl(${hue},100%,30%)`
        : `0 0 10px ${highlightColor}`;
      const sp = spring({ frame: elapsed, fps, config: { damping: 10, stiffness: 400 } });
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.8, 1.0]) : 1})`;
      break;
    }

    case 'glitch': {
      const gX = isActive ? Math.sin(frame * 0.9) * 4 : 0;
      const gY = isActive ? Math.cos(frame * 0.7) * 2 : 0;
      const sk = isActive ? Math.sin(frame * 1.2) * 5 : 0;
      style.color = fontColor;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.transform = `translate(${gX}px, ${gY}px) skewX(${sk}deg)`;
      style.textShadow = isActive
        ? `${-gX * 0.8}px 0 0 #ff00ff, ${gX * 0.8}px 0 0 #00ffff, 0 0 15px ${highlightColor}`
        : `0 0 8px ${highlightColor}`;
      break;
    }

    case 'fire': {
      const fl = isActive ? Math.sin(frame * 1.2) * 3 : 0;
      const fl2 = isActive ? Math.cos(frame * 0.9) * 2 : 0;
      const hue = isActive ? 30 + Math.sin(frame * 0.4) * 15 : 30;
      style.backgroundImage = isActive
        ? `linear-gradient(0deg, hsl(${hue-10},100%,40%), hsl(${hue+10},100%,60%), #ffeeaa)`
        : 'linear-gradient(0deg, #ff6600, #ffaa00)';
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = `${outlineWidth}px rgba(255,80,0,0.5)`;
      style.transform = `translateY(${fl}px) skewX(${fl2}deg)`;
      style.textShadow = isActive
        ? `0 0 ${20 + fl * 2}px #ff6600, 0 0 ${35 + fl}px #ff4400, 0 0 50px rgba(255,0,0,0.5)`
        : '0 0 12px #ff6600';
      break;
    }

    case 'water': {
      const wave = isActive ? Math.sin(frame * 0.25) * 6 : 0;
      const wave2 = isActive ? Math.cos(frame * 0.2) * 3 : 0;
      const hue = isActive ? 190 + Math.sin(frame * 0.15) * 20 : 190;
      style.backgroundImage = isActive
        ? `linear-gradient(${180 + wave * 3}deg, #00ffff, hsl(${hue},100%,60%), #0055ff)`
        : 'linear-gradient(180deg, #00ffff, #00aaff)';
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = `${outlineWidth}px rgba(0,150,255,0.4)`;
      style.transform = `translateY(${wave}px) translateX(${wave2}px)`;
      style.textShadow = isActive
        ? `0 0 ${15 + Math.sin(frame * 0.3) * 5}px rgba(0,170,255,0.8), 0 ${wave}px 10px rgba(0,100,200,0.5)`
        : '0 0 10px #00aaff';
      break;
    }

    case 'rainbow': {
      const hue = (frame * 4) % 360;
      style.backgroundImage = `linear-gradient(135deg, hsl(${hue},100%,60%), hsl(${(hue+60)%360},100%,60%), hsl(${(hue+120)%360},100%,60%), hsl(${(hue+180)%360},100%,60%))`;
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = '0px transparent';
      style.transform = `scale(${isActive ? 1.05 + Math.sin(frame * 0.4) * 0.05 : 1})`;
      style.textShadow = `0 0 ${12 + Math.sin(frame * 0.5) * 4}px hsl(${hue},100%,70%)`;
      break;
    }

    case 'shadow': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 8, stiffness: 400 } });
      const sc = isActive ? interpolate(sp, [0, 1], [0.7, 1.1]) : 1;
      const d3 = Array.from({length: 5}, (_, i) => {
        const o = (i + 1) + (isActive ? Math.sin(frame * 0.3 + i) * 1 : 0);
        return `${o}px ${o}px 0px rgba(100,100,255,${0.4 - i * 0.06})`;
      }).join(', ');
      style.color = isActive ? highlightColor : fontColor;
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.textShadow = d3;
      style.transform = `scale(${sc})`;
      break;
    }

    case 'pixel': {
      const sc = isActive ? 1 + Math.sin(frame * 0.5) * 0.05 : 1;
      style.color = isActive ? highlightColor : fontColor;
      style.fontFamily = "'Press Start 2P', monospace";
      style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.textShadow = isActive
        ? `-2px -2px 0 ${outlineColor}, 2px 2px 0 ${outlineColor}, 0 0 10px ${highlightColor}`
        : `-1px -1px 0 ${outlineColor}, 1px 1px 0 ${outlineColor}`;
      style.transform = `scale(${sc})`;
      style.opacity = isActive ? 0.8 + Math.sin(frame * 1.5) * 0.2 : 1;
      break;
    }

    case 'retro': {
      const swing = isActive ? Math.sin(frame * 0.3) * 8 : 0;
      const sw2 = isActive ? Math.cos(frame * 0.25) * 6 : 0;
      style.color = isActive ? highlightColor : fontColor;
      style.WebkitTextStroke = '0px transparent';
      style.textShadow = isActive
        ? `${sw2 * 0.4}px ${3 + Math.sin(frame * 0.2) * 2}px 0px rgba(255,68,170,0.8), 0 0 ${15 + Math.sin(frame * 0.5) * 5}px rgba(255,136,204,0.6)`
        : '2px 2px 0px rgba(255,68,170,0.6)';
      style.transform = `rotate(${swing * 0.3}deg) translateX(${sw2 * 0.2}px)`;
      break;
    }

    case 'gradientcup': {
      const hue = (frame * 2.5) % 360;
      style.backgroundImage = `linear-gradient(${135 + Math.sin(frame * 0.2) * 20}deg, hsl(${hue},100%,60%), hsl(${(hue+150)%360},100%,60%), hsl(${(hue+270)%360},100%,60%))`;
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = '0px transparent';
      const sp = spring({ frame: elapsed, fps, config: { damping: 8, stiffness: 400 } });
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.7, 1.05]) : 1})`;
      style.textShadow = `0 0 ${15 + Math.sin(frame * 0.4) * 5}px hsl(${hue},100%,70%)`;
      break;
    }

    case 'outline': {
      const outHue = (frame * 2) % 360;
      const oW = isActive ? outlineWidth + Math.sin(frame * 0.5) * 1.5 : outlineWidth;
      style.color = fontColor;
      style.WebkitTextStroke = `${oW}px hsl(${outHue},100%,60%)`;
      style.textShadow = isActive
        ? `0 0 ${8 + Math.sin(frame * 0.4) * 4}px hsl(${outHue},100%,70%)`
        : 'none';
      const sp = spring({ frame: elapsed, fps, config: { damping: 10, stiffness: 350 } });
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.8, 1.0]) : 1})`;
      break;
    }

    case 'chrome': {
      const angle = (frame * 1.5) % 360;
      style.backgroundImage = `linear-gradient(${angle}deg, #aaa, #fff, #eee, #fff, #bbb, #888, #fff, #ccc)`;
      style.WebkitBackgroundClip = 'text';
      style.WebkitTextFillColor = 'transparent';
      style.color = 'transparent';
      style.WebkitTextStroke = `${outlineWidth}px rgba(255,255,255,0.3)`;
      style.textShadow = `0 0 ${10 + Math.sin(frame * 0.3) * 4}px rgba(255,255,0,0.5), 2px 2px 4px rgba(0,0,0,0.5)`;
      const sp = spring({ frame: elapsed, fps, config: { damping: 12, stiffness: 380 } });
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.85, 1.0]) : 1})`;
      break;
    }

    case 'glass': {
      const sp = spring({ frame: elapsed, fps, config: { damping: 15, stiffness: 280 } });
      style.color = isActive
        ? `rgba(255,255,255,${0.55 + Math.sin(frame * 0.3) * 0.2})`
        : 'rgba(255,255,255,0.4)';
      style.WebkitTextStroke = `${outlineWidth}px rgba(255,255,255,${0.6 + Math.sin(frame * 0.25) * 0.2})`;
      style.textShadow = isActive
        ? `0 0 ${12 + Math.sin(frame * 0.35) * 5}px rgba(255,255,255,0.8)`
        : '0 0 8px rgba(255,255,255,0.5)';
      style.backgroundColor = `rgba(255,255,255,${isActive ? 0.08 + Math.sin(frame * 0.2) * 0.03 : 0.05})`;
      style.padding = '10px 24px';
      style.borderRadius = '12px';
      style.border = `1px solid rgba(255,255,255,${0.2 + Math.sin(frame * 0.3) * 0.1})`;
      style.opacity = isActive ? interpolate(sp, [0, 1], [0, 1]) : 0.8;
      break;
    }

    default: {
      const sp = spring({ frame: elapsed, fps, config: { damping: 10, stiffness: 400 } });
      style.color = isActive ? highlightColor : fontColor;
      if (outlineWidth > 0) style.WebkitTextStroke = `${outlineWidth}px ${outlineColor}`;
      style.transform = `scale(${isActive ? interpolate(sp, [0, 1], [0.7, 1.1]) : 1})`;
      break;
    }
  }

  return <div style={style}>{text}</div>;
};
